# 视觉小说类AVG游戏创作录屏

#### 说明介绍
**该游戏片段截取于Tomorrow is AGI团队利用Mariana WorkFlow技术概念搭建的基于AIGC的游戏创作，其中利用AIGC实现以下内容：**

1.  GPT-4实现Unity编辑器搭建+2D动效场景
2.  Midjourney + Stable Diffusion实现全游戏人物+背景+道具美术形象
3.  GPT-4实现游戏内容策划及游戏玩法&机制

#### 其他描述
1. 视频时长：1分钟
2. 展示效果：Mariana WorkFlow实现的游戏片段，全AI生产的人物，背景，语言，音乐，道具
